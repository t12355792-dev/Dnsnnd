package com.example.haven;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HavenMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("havenmod");

    @Override
    public void onInitialize() {
        ModContent.init();

        Registry.register(Registries.ITEM_GROUP, Identifier.of(ModContent.ID, "main"),
            FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.havenmod.main"))
                .icon(() -> new ItemStack(ModContent.GALAXY_AXE))
                .entries((ctx, entries) -> ModContent.TAB.forEach(entries::add))
                .build());

        // генерация руд: 0 рунная, 1 грозовая, 2 пылающая (Незер), 3 небесная, 4 космическая (Энд)
        for (int i = 0; i < ModContent.MATS.length; i++) {
            RegistryKey<PlacedFeature> key = RegistryKey.of(RegistryKeys.PLACED_FEATURE,
                    Identifier.of(ModContent.ID, ModContent.MATS[i] + "_ore"));
            var selector = (i == 2) ? BiomeSelectors.foundInTheNether()
                         : (i == 4) ? BiomeSelectors.foundInTheEnd()
                         : BiomeSelectors.foundInOverworld();
            BiomeModifications.addFeature(selector, GenerationStep.Feature.UNDERGROUND_ORES, key);
        }

        // Топор Галактики: атрибут урона в игре ограничен 2048, поэтому настоящие 7777 наносим здесь
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() || !(world instanceof ServerWorld sw)) return ActionResult.PASS;
            if (!player.getMainHandStack().isOf(ModContent.GALAXY_AXE)) return ActionResult.PASS;
            if (entity instanceof LivingEntity le && entity != player) {
                le.damage(sw, sw.getDamageSources().playerAttack(player), 7777f);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        Bosses.init();
        Lepidodendron.init();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            // /galaktika — выдаёт Топор Галактики
            dispatcher.register(CommandManager.literal("galaktika").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayer();
                if (p == null) {
                    ctx.getSource().sendError(Text.literal("Команду может выполнить только игрок."));
                    return 0;
                }
                p.giveItemStack(new ItemStack(ModContent.GALAXY_AXE));
                ctx.getSource().sendFeedback(() -> Text.literal("Вы получили ТОПОР ГАЛАКТИКИ (7777 урона)."), false);
                return 1;
            }));

            // /lepidodendron — дерево в 20 блоках перед вами
            dispatcher.register(CommandManager.literal("lepidodendron").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayer();
                if (p == null) {
                    ctx.getSource().sendError(Text.literal("Команду может выполнить только игрок."));
                    return 0;
                }
                ServerWorld w = ctx.getSource().getWorld();
                double yaw = Math.toRadians(p.getYaw());
                double x = p.getX() - Math.sin(yaw) * 20.0;
                double z = p.getZ() + Math.cos(yaw) * 20.0;
                boolean ok = Lepidodendron.spawnAt(w, (int) Math.floor(x), (int) Math.floor(z), w.random, true);
                for (int i = 0; i < 24 && !ok; i++) {
                    ok = Lepidodendron.spawnNear(w, p.getX(), p.getZ(), 20, 21, w.random, true);
                }
                if (!ok) {
                    ctx.getSource().sendError(Text.literal("Не нашлось подходящего места (нужна загруженная суша)."));
                    return 0;
                }
                ctx.getSource().sendFeedback(() -> Text.literal("Рядом появился лепидодендрон! Не подходите ближе 7 блоков."), false);
                return 1;
            }));

            // /wtboss <id> — призвать босса или мини-босса
            var root = CommandManager.literal("wtboss");
            for (String id : Bosses.ids()) {
                root.then(CommandManager.literal(id).executes(ctx -> {
                    ServerWorld w = ctx.getSource().getWorld();
                    Vec3d pos = ctx.getSource().getPosition();
                    boolean ok = Bosses.summon(w, id, pos.x + 3, pos.y, pos.z);
                    if (!ok) {
                        ctx.getSource().sendError(Text.literal("Не удалось призвать."));
                        return 0;
                    }
                    ctx.getSource().sendFeedback(() -> Text.literal("Призван: " + id), true);
                    return 1;
                }));
            }
            dispatcher.register(root);
        });
    }
}
