package com.example.haven;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Дерево лепидодендрон, редкий спавн рядом с игроком и телепорт в мир лепидодендронов. */
public final class Lepidodendron {
    public static final RegistryKey<World> DIM =
            RegistryKey.of(RegistryKeys.WORLD, Identifier.of(ModContent.ID, "lepidodendron"));

    static final int TRIGGER_RADIUS = 7;
    static final int DEATH_TICKS = 2 * 60 * 20;   // 2 минуты
    static final int RARE_CHANCE = 500;            // раз в 5 секунд шанс 1/500 на игрока (в среднем ~40 мин)

    private static final Map<UUID, Integer> TIMERS = new HashMap<>();
    private static final int[][] DIRS = {{1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}};

    private Lepidodendron() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(Lepidodendron::tick);
    }

    // ------------------------------------------------------------------ тик

    private static void tick(MinecraftServer server) {
        int t = server.getTicks();
        for (ServerWorld w : server.getWorlds()) {
            boolean inDim = w.getRegistryKey().equals(DIM);
            for (ServerPlayerEntity p : w.getPlayers()) {
                try {
                    if (inDim) tickInDimension(w, p, t);
                    else tickOutside(server, w, p, t);
                } catch (Exception ex) {
                    HavenMod.LOGGER.error("lepidodendron tick failed", ex);
                }
            }
        }
    }

    private static void tickInDimension(ServerWorld w, ServerPlayerEntity p, int t) {
        UUID id = p.getUuid();
        int left = TIMERS.getOrDefault(id, DEATH_TICKS) - 1;
        if (left <= 0) {
            TIMERS.remove(id);
            p.damage(w, w.getDamageSources().genericKill(), Float.MAX_VALUE);
            return;
        }
        TIMERS.put(id, left);

        if (t % 20 == 0) {
            p.sendMessage(Text.literal("Лепидодендроны высасывают жизнь... осталось " + (left / 20) + " с"), true);
        }
        if (t % 40 == 0) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        if (t % 10 == 0) {
            Random r = w.random;
            for (int i = 0; i < 2; i++) spawnNear(w, p.getX(), p.getZ(), 6, 56, r, false);
        }
    }

    private static void tickOutside(MinecraftServer server, ServerWorld w, ServerPlayerEntity p, int t) {
        TIMERS.remove(p.getUuid());
        if (p.isSpectator()) return;

        if (t % 100 == 0 && w.random.nextInt(RARE_CHANCE) == 0) {
            spawnNear(w, p.getX(), p.getZ(), 24, 48, w.random, false);
        }
        if (t % 10 == 0 && nearTree(w, p.getBlockPos())) {
            sendToDimension(server, p);
        }
    }

    private static boolean nearTree(ServerWorld w, BlockPos c) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int r = TRIGGER_RADIUS;
        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r * r) continue;
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (w.getBlockState(m).isOf(ModContent.LEPIDODENDRON_LOG)) return true;
                }
        return false;
    }

    private static void sendToDimension(MinecraftServer server, ServerPlayerEntity p) {
        TIMERS.put(p.getUuid(), DEATH_TICKS);
        String cmd = String.format(Locale.ROOT, "execute in %s:lepidodendron run tp %s %.2f 6 %.2f",
                ModContent.ID, p.getUuidAsString(), p.getX(), p.getZ());
        try {
            server.getCommandManager().getDispatcher().execute(cmd, server.getCommandSource().withSilent());
        } catch (Exception ex) {
            HavenMod.LOGGER.error("teleport to lepidodendron dimension failed", ex);
        }
        p.sendMessage(Text.literal("Вас затянуло в мир лепидодендронов. У вас 2 минуты."), false);
    }

    // ------------------------------------------------------------ генерация

    private static boolean loaded(ServerWorld w, int x, int z) {
        return w.getChunkManager().getWorldChunk(x >> 4, z >> 4) != null;
    }

    /** @return true если дерево поставлено */
    public static boolean spawnNear(ServerWorld w, double cx, double cz, double minR, double maxR, Random r, boolean force) {
        double a = r.nextDouble() * Math.PI * 2;
        double dist = minR + r.nextDouble() * (maxR - minR);
        return spawnAt(w, (int) Math.floor(cx + Math.cos(a) * dist), (int) Math.floor(cz + Math.sin(a) * dist), r, force);
    }

    public static boolean spawnAt(ServerWorld w, int x, int z, Random r, boolean force) {
        if (!loaded(w, x, z)) return false;
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        return generate(w, new BlockPos(x, y, z), r, force);
    }

    public static boolean generate(ServerWorld w, BlockPos base, Random r, boolean force) {
        BlockState ground = w.getBlockState(base.down());
        boolean okGround = ground.isIn(BlockTags.DIRT) || ground.isIn(BlockTags.SAND);
        if (!okGround && !(force && !ground.isAir() && ground.getFluidState().isEmpty())) return false;
        BlockState here = w.getBlockState(base);
        if (!here.isAir() && !here.isReplaceable()) return false;
        for (int cx = -1; cx <= 1; cx++)
            for (int cz = -1; cz <= 1; cz++)
                if (!loaded(w, base.getX() + cx * 16, base.getZ() + cz * 16)) return false;

        BlockState log = ModContent.LEPIDODENDRON_LOG.getDefaultState();
        BlockState leaves = ModContent.LEPIDODENDRON_LEAVES.getDefaultState();
        int h = 14 + r.nextInt(11);

        for (int y = 0; y <= h; y++) put(w, base.up(y), log);
        for (int i = 0; i < 8; i += 2) {
            put(w, base.add(DIRS[i][0], 0, DIRS[i][1]), log);
            if (r.nextBoolean()) put(w, base.add(DIRS[i][0], 1, DIRS[i][1]), log);
        }
        // «чешуйки» — пучки хвои, торчащие из ствола
        for (int y = h / 2; y < h - 1; y += 2) {
            int[] d = DIRS[r.nextInt(8)];
            if (r.nextInt(3) != 0) put(w, base.add(d[0], y, d[1]), leaves);
        }
        // раздваивающаяся крона
        int d0 = r.nextInt(8);
        int[] offs = {0, 3, 5};
        for (int o : offs) branch(w, base.up(h), (d0 + o) & 7, 4, 2, log, leaves);
        cluster(w, base.up(h + 1), 2, leaves);
        return true;
    }

    private static void branch(ServerWorld w, BlockPos start, int dir, int steps, int depth, BlockState log, BlockState leaves) {
        BlockPos p = start;
        int[] d = DIRS[dir];
        for (int i = 0; i < steps; i++) {
            if (i % 2 == 0) {
                p = p.add(d[0], 0, 0);
                put(w, p, log);
                p = p.add(0, 0, d[1]);
                put(w, p, log);
            }
            p = p.up();
            put(w, p, log);
        }
        if (depth > 0) {
            cluster(w, p, 1, leaves);
            branch(w, p, (dir + 1) & 7, steps - 1, depth - 1, log, leaves);
            branch(w, p, (dir + 7) & 7, steps - 1, depth - 1, log, leaves);
        } else {
            cluster(w, p, 2, leaves);
        }
    }

    private static void cluster(ServerWorld w, BlockPos c, int radius, BlockState leaves) {
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                for (int dy = -1; dy <= 1; dy++)
                    if (dx * dx + dz * dz + dy * dy * 2 <= radius * radius + 1)
                        put(w, c.add(dx, dy, dz), leaves);
    }

    private static void put(ServerWorld w, BlockPos p, BlockState s) {
        BlockState cur = w.getBlockState(p);
        if (cur.isAir() || cur.isReplaceable() || cur.isIn(BlockTags.LEAVES)) {
            w.setBlockState(p, s, Block.NOTIFY_LISTENERS);
        }
    }
}
